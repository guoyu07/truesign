'use strict';

// this file is not transpiled in dev

require('babel-polyfill');
require('./options').registerNodeOptions();
