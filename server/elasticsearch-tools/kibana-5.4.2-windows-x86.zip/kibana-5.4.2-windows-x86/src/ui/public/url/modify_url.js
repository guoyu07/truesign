// we select the modify_url directly so the other utils, which are not browser compatible, are not included
export { modifyUrl } from '../../../utils/modify_url';
