import uiRegistry from 'ui/registry/_registry';
export default uiRegistry({
  name: 'visTypes',
  index: ['name'],
  order: ['title']
});
